package airlineassignment;
import static airlineassignment.CreateDatabase.url;
import java.sql.*;
/**
 *
 * @author gavin
 */
public class DBQueries {
        //global url for db location, use mydb for the folder and your name for the DB
    
    
    static String count(){
        String x = null; // string value to be returned from method call
        //try and make a connection to the DB using the gloabal URL variable
        //The connection and statements objects might be better if global?
        
        try (Connection conn = DriverManager.getConnection(url)){
          String count = "SELECT COUNT(*) FROM CUSTOMER"; //string query called count
          //Statement – Used to execute string-based SQL queries
          Statement st1 = conn.createStatement();
          ResultSet rs1 = st1.executeQuery(count); //result set from query
          while (rs1.next()) //rs is result set, use while to iterate through it
          {
            String mycount = rs1.getString(1); //get string from location 1 in RS
            x = mycount; // assign string from location 1 in RS to x
          } //end while
          st1.close(); //close statement, may not be needed, probably a good thing to do
        } //end try catch
        catch (Exception e)
        {
          System.err.println("Got an exception! "); //println for catching error, popup would be better
          System.err.println(e.getMessage()); //println for catching error, popup would be better
        }
        return x; // value to be returned from method call
    } //end count method

    static String average(){  
    String x = null; // string value to be returned from method call
        //try and make a connection to the DB using the gloabal URL variable
        //The connection and statements objects might be better if global?
        try (Connection conn = DriverManager.getConnection(url)){
          String avg = "SELECT AVG(Age) FROM CUSTOMER"; //string query called avg
          Statement st3 = conn.createStatement();
          ResultSet rs3 = st3.executeQuery(avg); //result set from query
          while (rs3.next()) //rs2 is result set, use while to iterate through it
          {
            String itemavg = rs3.getString(1); //get string from location 1 in rs2
            x = itemavg; // assign string from location 1 in RS to x
          }
          st3.close(); //close statement, may not be needed, probably a good thing to do
        }
        catch (Exception e)
        {
          System.err.println("Got an exception! "); //println for catching error, popup would be better
          System.err.println(e.getMessage()); //println for catching error, popup would be better
        }
        return x; // value to be returned from method call
    }//end average method

    
        static String countTicket(){
        String x = null; // string value to be returned from method call
        //try and make a connection to the DB using the gloabal URL variable
        //The connection and statements objects might be better if global?
        try (Connection conn = DriverManager.getConnection(url)){
          String count = "SELECT COUNT(PASSENGERNUMBERS) FROM FLIGHTS"; //string query called count
          //Statement – Used to execute string-based SQL queries
          Statement st1 = conn.createStatement();
          ResultSet rs1 = st1.executeQuery(count); //result set from query
          while (rs1.next()) //rs is result set, use while to iterate through it
          {
            String mycount = rs1.getString(1); //get string from location 1 in RS
            x = mycount; // assign string from location 1 in RS to x
          } //end while
          st1.close(); //close statement, may not be needed, probably a good thing to do
        } //end try catch
        catch (Exception e)
        {
          System.err.println("Got an exception! "); //println for catching error, popup would be better
          System.err.println(e.getMessage()); //println for catching error, popup would be better
        }
        return x; // value to be returned from method call
    } //end count method
    
        static String averageTicket(){  
    String x = null; // string value to be returned from method call
        //try and make a connection to the DB using the gloabal URL variable
        //The connection and statements objects might be better if global?
        try (Connection conn = DriverManager.getConnection(url)){
          String avg = "SELECT AVG(TICKETPRICE) FROM FLIGHTS"; //string query called avg
          Statement st3 = conn.createStatement();
          ResultSet rs3 = st3.executeQuery(avg); //result set from query
          while (rs3.next()) //rs2 is result set, use while to iterate through it
          {
            String itemavg = rs3.getString(1); //get string from location 1 in rs2
            x = itemavg; // assign string from location 1 in RS to x
          }
          st3.close(); //close statement, may not be needed, probably a good thing to do
        }
        catch (Exception e)
        {
          System.err.println("Got an exception! "); //println for catching error, popup would be better
          System.err.println(e.getMessage()); //println for catching error, popup would be better
        }
        return x; // value to be returned from method call
    }//end average method
    
} //end DBQueries class

    

