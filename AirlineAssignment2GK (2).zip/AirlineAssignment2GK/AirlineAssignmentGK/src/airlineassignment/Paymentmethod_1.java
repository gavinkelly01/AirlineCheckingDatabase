/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package airlineassignment;

import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;
import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Transient;

/**
 *
 * @author gavin
 */
@Entity
@Table(name = "PAYMENTMETHOD", catalog = "", schema = "")
@NamedQueries({
    @NamedQuery(name = "Paymentmethod_1.findAll", query = "SELECT p FROM Paymentmethod_1 p")
    , @NamedQuery(name = "Paymentmethod_1.findByCreditcardname", query = "SELECT p FROM Paymentmethod_1 p WHERE p.creditcardname = :creditcardname")
    , @NamedQuery(name = "Paymentmethod_1.findByCreditcardnumber", query = "SELECT p FROM Paymentmethod_1 p WHERE p.creditcardnumber = :creditcardnumber")
    , @NamedQuery(name = "Paymentmethod_1.findByExpirycode", query = "SELECT p FROM Paymentmethod_1 p WHERE p.expirycode = :expirycode")
    , @NamedQuery(name = "Paymentmethod_1.findBySecuritycode", query = "SELECT p FROM Paymentmethod_1 p WHERE p.securitycode = :securitycode")})
public class Paymentmethod_1 implements Serializable {

    @Transient
    private PropertyChangeSupport changeSupport = new PropertyChangeSupport(this);

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @Column(name = "CREDITCARDNAME")
    private String creditcardname;
    @Column(name = "CREDITCARDNUMBER")
    private String creditcardnumber;
    @Column(name = "EXPIRYCODE")
    private String expirycode;
    @Column(name = "SECURITYCODE")
    private String securitycode;

    public Paymentmethod_1() {
    }

    public Paymentmethod_1(String creditcardname) {
        this.creditcardname = creditcardname;
    }

    public String getCreditcardname() {
        return creditcardname;
    }

    public void setCreditcardname(String creditcardname) {
        String oldCreditcardname = this.creditcardname;
        this.creditcardname = creditcardname;
        changeSupport.firePropertyChange("creditcardname", oldCreditcardname, creditcardname);
    }

    public String getCreditcardnumber() {
        return creditcardnumber;
    }

    public void setCreditcardnumber(String creditcardnumber) {
        String oldCreditcardnumber = this.creditcardnumber;
        this.creditcardnumber = creditcardnumber;
        changeSupport.firePropertyChange("creditcardnumber", oldCreditcardnumber, creditcardnumber);
    }

    public String getExpirycode() {
        return expirycode;
    }

    public void setExpirycode(String expirycode) {
        String oldExpirycode = this.expirycode;
        this.expirycode = expirycode;
        changeSupport.firePropertyChange("expirycode", oldExpirycode, expirycode);
    }

    public String getSecuritycode() {
        return securitycode;
    }

    public void setSecuritycode(String securitycode) {
        String oldSecuritycode = this.securitycode;
        this.securitycode = securitycode;
        changeSupport.firePropertyChange("securitycode", oldSecuritycode, securitycode);
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (creditcardname != null ? creditcardname.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Paymentmethod_1)) {
            return false;
        }
        Paymentmethod_1 other = (Paymentmethod_1) object;
        if ((this.creditcardname == null && other.creditcardname != null) || (this.creditcardname != null && !this.creditcardname.equals(other.creditcardname))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "airlineassignment.Paymentmethod_1[ creditcardname=" + creditcardname + " ]";
    }

    public void addPropertyChangeListener(PropertyChangeListener listener) {
        changeSupport.addPropertyChangeListener(listener);
    }

    public void removePropertyChangeListener(PropertyChangeListener listener) {
        changeSupport.removePropertyChangeListener(listener);
    }
    
}
