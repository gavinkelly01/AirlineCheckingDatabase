/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package airlineassignment;

import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;
import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Transient;

/**
 *
 * @author gavin
 */
@Entity
@Table(name = "FLIGHTS", catalog = "", schema = "")
@NamedQueries({
    @NamedQuery(name = "Flights.findAll", query = "SELECT f FROM Flights f")
    , @NamedQuery(name = "Flights.findByFlightnumber", query = "SELECT f FROM Flights f WHERE f.flightnumber = :flightnumber")
    , @NamedQuery(name = "Flights.findByTicketprice", query = "SELECT f FROM Flights f WHERE f.ticketprice = :ticketprice")
    , @NamedQuery(name = "Flights.findByGatenumber", query = "SELECT f FROM Flights f WHERE f.gatenumber = :gatenumber")
    , @NamedQuery(name = "Flights.findByPassengernumber", query = "SELECT f FROM Flights f WHERE f.passengernumber = :passengernumber")
    , @NamedQuery(name = "Flights.findByAvailability", query = "SELECT f FROM Flights f WHERE f.availability = :availability")
    , @NamedQuery(name = "Flights.findByFlightdate", query = "SELECT f FROM Flights f WHERE f.flightdate = :flightdate")
    , @NamedQuery(name = "Flights.findByDeparturelocation", query = "SELECT f FROM Flights f WHERE f.departurelocation = :departurelocation")
    , @NamedQuery(name = "Flights.findByDeparturetime", query = "SELECT f FROM Flights f WHERE f.departuretime = :departuretime")
    , @NamedQuery(name = "Flights.findByArrivallocation", query = "SELECT f FROM Flights f WHERE f.arrivallocation = :arrivallocation")
    , @NamedQuery(name = "Flights.findByArrivaltime", query = "SELECT f FROM Flights f WHERE f.arrivaltime = :arrivaltime")})
public class Flights implements Serializable {

    @Transient
    private PropertyChangeSupport changeSupport = new PropertyChangeSupport(this);

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @Column(name = "FLIGHTNUMBER")
    private String flightnumber;
    @Column(name = "TICKETPRICE")
    private String ticketprice;
    @Column(name = "GATENUMBER")
    private String gatenumber;
    @Column(name = "PASSENGERNUMBER")
    private String passengernumber;
    @Column(name = "AVAILABILITY")
    private String availability;
    @Column(name = "FLIGHTDATE")
    private String flightdate;
    @Column(name = "DEPARTURELOCATION")
    private String departurelocation;
    @Column(name = "DEPARTURETIME")
    private String departuretime;
    @Column(name = "ARRIVALLOCATION")
    private String arrivallocation;
    @Column(name = "ARRIVALTIME")
    private String arrivaltime;

    public Flights() {
    }

    public Flights(String flightnumber) {
        this.flightnumber = flightnumber;
    }

    public String getFlightnumber() {
        return flightnumber;
    }

    public void setFlightnumber(String flightnumber) {
        String oldFlightnumber = this.flightnumber;
        this.flightnumber = flightnumber;
        changeSupport.firePropertyChange("flightnumber", oldFlightnumber, flightnumber);
    }

    public String getTicketprice() {
        return ticketprice;
    }

    public void setTicketprice(String ticketprice) {
        String oldTicketprice = this.ticketprice;
        this.ticketprice = ticketprice;
        changeSupport.firePropertyChange("ticketprice", oldTicketprice, ticketprice);
    }

    public String getGatenumber() {
        return gatenumber;
    }

    public void setGatenumber(String gatenumber) {
        String oldGatenumber = this.gatenumber;
        this.gatenumber = gatenumber;
        changeSupport.firePropertyChange("gatenumber", oldGatenumber, gatenumber);
    }

    public String getPassengernumber() {
        return passengernumber;
    }

    public void setPassengernumber(String passengernumber) {
        String oldPassengernumber = this.passengernumber;
        this.passengernumber = passengernumber;
        changeSupport.firePropertyChange("passengernumber", oldPassengernumber, passengernumber);
    }

    public String getAvailability() {
        return availability;
    }

    public void setAvailability(String availability) {
        String oldAvailability = this.availability;
        this.availability = availability;
        changeSupport.firePropertyChange("availability", oldAvailability, availability);
    }

    public String getFlightdate() {
        return flightdate;
    }

    public void setFlightdate(String flightdate) {
        String oldFlightdate = this.flightdate;
        this.flightdate = flightdate;
        changeSupport.firePropertyChange("flightdate", oldFlightdate, flightdate);
    }

    public String getDeparturelocation() {
        return departurelocation;
    }

    public void setDeparturelocation(String departurelocation) {
        String oldDeparturelocation = this.departurelocation;
        this.departurelocation = departurelocation;
        changeSupport.firePropertyChange("departurelocation", oldDeparturelocation, departurelocation);
    }

    public String getDeparturetime() {
        return departuretime;
    }

    public void setDeparturetime(String departuretime) {
        String oldDeparturetime = this.departuretime;
        this.departuretime = departuretime;
        changeSupport.firePropertyChange("departuretime", oldDeparturetime, departuretime);
    }

    public String getArrivallocation() {
        return arrivallocation;
    }

    public void setArrivallocation(String arrivallocation) {
        String oldArrivallocation = this.arrivallocation;
        this.arrivallocation = arrivallocation;
        changeSupport.firePropertyChange("arrivallocation", oldArrivallocation, arrivallocation);
    }

    public String getArrivaltime() {
        return arrivaltime;
    }

    public void setArrivaltime(String arrivaltime) {
        String oldArrivaltime = this.arrivaltime;
        this.arrivaltime = arrivaltime;
        changeSupport.firePropertyChange("arrivaltime", oldArrivaltime, arrivaltime);
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (flightnumber != null ? flightnumber.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Flights)) {
            return false;
        }
        Flights other = (Flights) object;
        if ((this.flightnumber == null && other.flightnumber != null) || (this.flightnumber != null && !this.flightnumber.equals(other.flightnumber))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "airlineassignment.Flights[ flightnumber=" + flightnumber + " ]";
    }

    public void addPropertyChangeListener(PropertyChangeListener listener) {
        changeSupport.addPropertyChangeListener(listener);
    }

    public void removePropertyChangeListener(PropertyChangeListener listener) {
        changeSupport.removePropertyChangeListener(listener);
    }
    
}
