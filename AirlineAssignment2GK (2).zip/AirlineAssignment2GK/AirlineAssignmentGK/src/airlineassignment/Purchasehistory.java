/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package airlineassignment;

import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;
import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Transient;

/**
 *
 * @author gavin
 */
@Entity
@Table(name = "PURCHASEHISTORY", catalog = "", schema = "")
@NamedQueries({
    @NamedQuery(name = "Purchasehistory.findAll", query = "SELECT p FROM Purchasehistory p")
    , @NamedQuery(name = "Purchasehistory.findByReceiptnumber", query = "SELECT p FROM Purchasehistory p WHERE p.receiptnumber = :receiptnumber")
    , @NamedQuery(name = "Purchasehistory.findByFlightnumber", query = "SELECT p FROM Purchasehistory p WHERE p.flightnumber = :flightnumber")
    , @NamedQuery(name = "Purchasehistory.findByTicketprice", query = "SELECT p FROM Purchasehistory p WHERE p.ticketprice = :ticketprice")
    , @NamedQuery(name = "Purchasehistory.findByEmail", query = "SELECT p FROM Purchasehistory p WHERE p.email = :email")
    , @NamedQuery(name = "Purchasehistory.findByGatenumber", query = "SELECT p FROM Purchasehistory p WHERE p.gatenumber = :gatenumber")
    , @NamedQuery(name = "Purchasehistory.findByPassengernumber", query = "SELECT p FROM Purchasehistory p WHERE p.passengernumber = :passengernumber")
    , @NamedQuery(name = "Purchasehistory.findByAvailability", query = "SELECT p FROM Purchasehistory p WHERE p.availability = :availability")
    , @NamedQuery(name = "Purchasehistory.findByFlightdate", query = "SELECT p FROM Purchasehistory p WHERE p.flightdate = :flightdate")
    , @NamedQuery(name = "Purchasehistory.findByDeparturelocation", query = "SELECT p FROM Purchasehistory p WHERE p.departurelocation = :departurelocation")
    , @NamedQuery(name = "Purchasehistory.findByDeparturetime", query = "SELECT p FROM Purchasehistory p WHERE p.departuretime = :departuretime")
    , @NamedQuery(name = "Purchasehistory.findByArrivallocation", query = "SELECT p FROM Purchasehistory p WHERE p.arrivallocation = :arrivallocation")
    , @NamedQuery(name = "Purchasehistory.findByArrivaltime", query = "SELECT p FROM Purchasehistory p WHERE p.arrivaltime = :arrivaltime")})
public class Purchasehistory implements Serializable {

    @Transient
    private PropertyChangeSupport changeSupport = new PropertyChangeSupport(this);

    private static final long serialVersionUID = 1L;
    @Id
    @Column(name = "RECEIPTNUMBER")
    private String receiptnumber;
    @Basic(optional = false)
    @Column(name = "FLIGHTNUMBER")
    private String flightnumber;
    @Column(name = "TICKETPRICE")
    private String ticketprice;
    @Column(name = "EMAIL")
    private String email;
    @Column(name = "GATENUMBER")
    private String gatenumber;
    @Column(name = "PASSENGERNUMBER")
    private String passengernumber;
    @Column(name = "AVAILABILITY")
    private String availability;
    @Column(name = "FLIGHTDATE")
    private String flightdate;
    @Column(name = "DEPARTURELOCATION")
    private String departurelocation;
    @Column(name = "DEPARTURETIME")
    private String departuretime;
    @Column(name = "ARRIVALLOCATION")
    private String arrivallocation;
    @Column(name = "ARRIVALTIME")
    private String arrivaltime;

    public Purchasehistory() {
    }

    public Purchasehistory(String receiptnumber) {
        this.receiptnumber = receiptnumber;
    }

    public Purchasehistory(String receiptnumber, String flightnumber) {
        this.receiptnumber = receiptnumber;
        this.flightnumber = flightnumber;
    }

    public String getReceiptnumber() {
        return receiptnumber;
    }

    public void setReceiptnumber(String receiptnumber) {
        String oldReceiptnumber = this.receiptnumber;
        this.receiptnumber = receiptnumber;
        changeSupport.firePropertyChange("receiptnumber", oldReceiptnumber, receiptnumber);
    }

    public String getFlightnumber() {
        return flightnumber;
    }

    public void setFlightnumber(String flightnumber) {
        String oldFlightnumber = this.flightnumber;
        this.flightnumber = flightnumber;
        changeSupport.firePropertyChange("flightnumber", oldFlightnumber, flightnumber);
    }

    public String getTicketprice() {
        return ticketprice;
    }

    public void setTicketprice(String ticketprice) {
        String oldTicketprice = this.ticketprice;
        this.ticketprice = ticketprice;
        changeSupport.firePropertyChange("ticketprice", oldTicketprice, ticketprice);
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        String oldEmail = this.email;
        this.email = email;
        changeSupport.firePropertyChange("email", oldEmail, email);
    }

    public String getGatenumber() {
        return gatenumber;
    }

    public void setGatenumber(String gatenumber) {
        String oldGatenumber = this.gatenumber;
        this.gatenumber = gatenumber;
        changeSupport.firePropertyChange("gatenumber", oldGatenumber, gatenumber);
    }

    public String getPassengernumber() {
        return passengernumber;
    }

    public void setPassengernumber(String passengernumber) {
        String oldPassengernumber = this.passengernumber;
        this.passengernumber = passengernumber;
        changeSupport.firePropertyChange("passengernumber", oldPassengernumber, passengernumber);
    }

    public String getAvailability() {
        return availability;
    }

    public void setAvailability(String availability) {
        String oldAvailability = this.availability;
        this.availability = availability;
        changeSupport.firePropertyChange("availability", oldAvailability, availability);
    }

    public String getFlightdate() {
        return flightdate;
    }

    public void setFlightdate(String flightdate) {
        String oldFlightdate = this.flightdate;
        this.flightdate = flightdate;
        changeSupport.firePropertyChange("flightdate", oldFlightdate, flightdate);
    }

    public String getDeparturelocation() {
        return departurelocation;
    }

    public void setDeparturelocation(String departurelocation) {
        String oldDeparturelocation = this.departurelocation;
        this.departurelocation = departurelocation;
        changeSupport.firePropertyChange("departurelocation", oldDeparturelocation, departurelocation);
    }

    public String getDeparturetime() {
        return departuretime;
    }

    public void setDeparturetime(String departuretime) {
        String oldDeparturetime = this.departuretime;
        this.departuretime = departuretime;
        changeSupport.firePropertyChange("departuretime", oldDeparturetime, departuretime);
    }

    public String getArrivallocation() {
        return arrivallocation;
    }

    public void setArrivallocation(String arrivallocation) {
        String oldArrivallocation = this.arrivallocation;
        this.arrivallocation = arrivallocation;
        changeSupport.firePropertyChange("arrivallocation", oldArrivallocation, arrivallocation);
    }

    public String getArrivaltime() {
        return arrivaltime;
    }

    public void setArrivaltime(String arrivaltime) {
        String oldArrivaltime = this.arrivaltime;
        this.arrivaltime = arrivaltime;
        changeSupport.firePropertyChange("arrivaltime", oldArrivaltime, arrivaltime);
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (receiptnumber != null ? receiptnumber.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Purchasehistory)) {
            return false;
        }
        Purchasehistory other = (Purchasehistory) object;
        if ((this.receiptnumber == null && other.receiptnumber != null) || (this.receiptnumber != null && !this.receiptnumber.equals(other.receiptnumber))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "airlineassignment.Purchasehistory[ receiptnumber=" + receiptnumber + " ]";
    }

    public void addPropertyChangeListener(PropertyChangeListener listener) {
        changeSupport.addPropertyChangeListener(listener);
    }

    public void removePropertyChangeListener(PropertyChangeListener listener) {
        changeSupport.removePropertyChangeListener(listener);
    }
    
}
