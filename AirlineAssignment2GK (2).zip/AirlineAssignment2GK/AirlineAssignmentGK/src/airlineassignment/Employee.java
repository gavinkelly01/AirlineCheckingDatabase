/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package airlineassignment;

import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;
import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Transient;

/**
 *
 * @author gavin
 */
@Entity
@Table(name = "EMPLOYEE", catalog = "", schema = "")
@NamedQueries({
    @NamedQuery(name = "Employee.findAll", query = "SELECT e FROM Employee e")
    , @NamedQuery(name = "Employee.findByEmployeeid", query = "SELECT e FROM Employee e WHERE e.employeeid = :employeeid")
    , @NamedQuery(name = "Employee.findByEmployeefirstname", query = "SELECT e FROM Employee e WHERE e.employeefirstname = :employeefirstname")
    , @NamedQuery(name = "Employee.findByEmployeesurname", query = "SELECT e FROM Employee e WHERE e.employeesurname = :employeesurname")
    , @NamedQuery(name = "Employee.findByFlightcrew", query = "SELECT e FROM Employee e WHERE e.flightcrew = :flightcrew")
    , @NamedQuery(name = "Employee.findByDate", query = "SELECT e FROM Employee e WHERE e.date = :date")})
public class Employee implements Serializable {

    @Transient
    private PropertyChangeSupport changeSupport = new PropertyChangeSupport(this);

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @Column(name = "EMPLOYEEID")
    private String employeeid;
    @Column(name = "EMPLOYEEFIRSTNAME")
    private String employeefirstname;
    @Column(name = "EMPLOYEESURNAME")
    private String employeesurname;
    @Column(name = "FLIGHTCREW")
    private String flightcrew;
    @Column(name = "DATE")
    private String date;

    public Employee() {
    }

    public Employee(String employeeid) {
        this.employeeid = employeeid;
    }

    public String getEmployeeid() {
        return employeeid;
    }

    public void setEmployeeid(String employeeid) {
        String oldEmployeeid = this.employeeid;
        this.employeeid = employeeid;
        changeSupport.firePropertyChange("employeeid", oldEmployeeid, employeeid);
    }

    public String getEmployeefirstname() {
        return employeefirstname;
    }

    public void setEmployeefirstname(String employeefirstname) {
        String oldEmployeefirstname = this.employeefirstname;
        this.employeefirstname = employeefirstname;
        changeSupport.firePropertyChange("employeefirstname", oldEmployeefirstname, employeefirstname);
    }

    public String getEmployeesurname() {
        return employeesurname;
    }

    public void setEmployeesurname(String employeesurname) {
        String oldEmployeesurname = this.employeesurname;
        this.employeesurname = employeesurname;
        changeSupport.firePropertyChange("employeesurname", oldEmployeesurname, employeesurname);
    }

    public String getFlightcrew() {
        return flightcrew;
    }

    public void setFlightcrew(String flightcrew) {
        String oldFlightcrew = this.flightcrew;
        this.flightcrew = flightcrew;
        changeSupport.firePropertyChange("flightcrew", oldFlightcrew, flightcrew);
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        String oldDate = this.date;
        this.date = date;
        changeSupport.firePropertyChange("date", oldDate, date);
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (employeeid != null ? employeeid.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Employee)) {
            return false;
        }
        Employee other = (Employee) object;
        if ((this.employeeid == null && other.employeeid != null) || (this.employeeid != null && !this.employeeid.equals(other.employeeid))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "airlineassignment.Employee[ employeeid=" + employeeid + " ]";
    }

    public void addPropertyChangeListener(PropertyChangeListener listener) {
        changeSupport.addPropertyChangeListener(listener);
    }

    public void removePropertyChangeListener(PropertyChangeListener listener) {
        changeSupport.removePropertyChangeListener(listener);
    }
    
}
